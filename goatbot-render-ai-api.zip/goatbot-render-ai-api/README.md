# GoatBot AI API (Render)

A small Node.js API for GoatBot Messenger commands. It provides API-key-protected AI endpoints.

## Endpoints

- `GET /` — service information
- `GET /health` — public health check
- `POST /v1/ai` — general AI response
- `POST /v1/chat` — concise Messenger-style response
- `POST /v1/summarize` — summarize text
- `POST /v1/translate` — translate text (send a `language` field)

All `/v1/*` endpoints require the `x-api-key` header.

## Deploy on Render

1. Upload these files to a GitHub repository.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Use these settings:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Health Check Path: `/health`
4. In the Render service's **Environment** settings, add:
   - `API_KEY` — a long random secret you create
   - `OPENAI_API_KEY` — your OpenAI API key
   - `OPENAI_MODEL` — optional; defaults to `gpt-4.1-mini`
5. Create the service and wait for deployment to finish.
6. Test `https://YOUR-SERVICE.onrender.com/health`.

Do not commit `.env` or publish your secrets. Render supplies `PORT` automatically.

## Create an API_KEY

Generate a strong random secret on your computer:

```bash
openssl rand -hex 32
```

Put the output in Render's `API_KEY` environment variable. Use the same value in GoatBot's private environment configuration as `AI_API_KEY`.

## Test

Health check:

```bash
curl https://YOUR-SERVICE.onrender.com/health
```

AI endpoint (replace URL and secret):

```bash
curl -X POST https://YOUR-SERVICE.onrender.com/v1/ai \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -d '{"text":"Explain Node.js in one sentence."}'
```

Expected success shape:

```json
{"success":true,"answer":"..."}
```

## Connect GoatBot

In the GoatBot runtime environment, set:

```dotenv
AI_API_URL=https://YOUR-SERVICE.onrender.com
AI_API_KEY=the_same_secret_as_the_API_KEY_environment_variable_on_Render
```

Keep these values private. Restart GoatBot after changing environment variables. The command file must use the command format supported by your particular GoatBot version.

## Notes

- AI responses require a valid OpenAI API key, model access, and available API quota; API usage may cost money.
- Render free web services can spin down when idle, so they may not provide uninterrupted 24/7 availability.
- This service limits `/v1` traffic to 20 requests per minute per client IP. Adjust cautiously if needed.
