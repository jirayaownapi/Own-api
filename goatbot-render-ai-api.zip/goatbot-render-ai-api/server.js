require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const OpenAI = require("openai");
const crypto = require("crypto");

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "20kb" }));

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

if (!API_KEY || !OPENAI_API_KEY) {
  console.error("Missing API_KEY or OPENAI_API_KEY environment variable.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

app.use("/v1", rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false
}));

function authenticate(req, res, next) {
  const supplied = req.get("x-api-key") || "";
  const expected = Buffer.from(API_KEY);
  const actual = Buffer.from(supplied);

  if (
    actual.length !== expected.length ||
    !crypto.timingSafeEqual(actual, expected)
  ) {
    return res.status(401).json({
      success: false,
      error: "Invalid API key"
    });
  }

  next();
}

app.get("/", (req, res) => {
  res.json({
    success: true,
    service: "GoatBot AI API",
    health: "/health",
    endpoints: ["POST /v1/ai", "POST /v1/chat", "POST /v1/summarize", "POST /v1/translate"]
  });
});

app.get("/health", (req, res) => {
  res.status(200).json({
    success: true,
    service: "GoatBot AI API",
    status: "online"
  });
});

app.use("/v1", authenticate);

function readText(req, res) {
  const text = req.body && req.body.text;

  if (typeof text !== "string" || !text.trim()) {
    res.status(400).json({
      success: false,
      error: "Provide a non-empty text field."
    });
    return null;
  }

  if (text.length > 8000) {
    res.status(413).json({
      success: false,
      error: "Text must be 8000 characters or fewer."
    });
    return null;
  }

  return text.trim();
}

async function createAnswer(instructions, input) {
  const result = await openai.responses.create({
    model: MODEL,
    instructions,
    input,
    max_output_tokens: 700
  });

  return result.output_text || "No response generated.";
}

async function handleAI(req, res, instructions) {
  const text = readText(req, res);
  if (text === null) return;

  try {
    const answer = await createAnswer(instructions, text);
    return res.json({ success: true, answer });
  } catch (error) {
    console.error("AI provider request failed:", error.status || error.message);
    return res.status(502).json({
      success: false,
      error: "AI provider request failed. Check the provider key, model access, and API quota."
    });
  }
}

app.post("/v1/ai", (req, res) =>
  handleAI(req, res, "You are a helpful assistant. Answer clearly and accurately.")
);

app.post("/v1/chat", (req, res) =>
  handleAI(req, res, "You are a friendly AI assistant for a Messenger bot. Be helpful and concise.")
);

app.post("/v1/summarize", (req, res) =>
  handleAI(req, res, "Summarize the user's text clearly and preserve the key points.")
);

app.post("/v1/translate", (req, res) => {
  const language = req.body && req.body.language;

  if (typeof language !== "string" || !/^[a-zA-Z -]{2,40}$/.test(language.trim())) {
    return res.status(400).json({
      success: false,
      error: "Provide a target language, for example English or Nepali."
    });
  }

  return handleAI(
    req,
    res,
    `Translate the user's text into ${language.trim()}. Return only the translation.`
  );
});

app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({
      success: false,
      error: "Invalid JSON request body."
    });
  }

  console.error("Server error:", err.message);
  return res.status(500).json({
    success: false,
    error: "Internal server error."
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`GoatBot AI API listening on port ${PORT}`);
});
